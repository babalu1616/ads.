import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function PackagesSection() {
  const packages = [
    {
      name: "Starter",
      description: "Perfect for small businesses",
      price: "₹15,000",
      period: "per month",
      features: [
        "1 Platform (Meta OR Google)",
        "Ad spend up to ₹50,000",
        "Basic audience research",
        "Monthly reporting",
        "Email support"
      ],
      buttonText: "Start Now",
      buttonClass: "bg-black text-white hover:bg-gray-800"
    },
    {
      name: "Growth",
      description: "Ideal for scaling businesses",
      price: "₹35,000",
      period: "per month",
      features: [
        "2 Platforms (Meta + Google)",
        "Ad spend up to ₹2,00,000",
        "Advanced targeting & optimization",
        "Weekly reporting & calls",
        "Phone + WhatsApp support",
        "Landing page optimization"
      ],
      buttonText: "Start Now",
      buttonClass: "bg-black text-white hover:bg-gray-800",
      popular: true
    },
    {
      name: "Premium",
      description: "For enterprise-level growth",
      price: "₹75,000",
      period: "per month",
      features: [
        "All 3 Platforms (Meta + Google + YouTube)",
        "Unlimited ad spend management",
        "Custom audience research & strategy",
        "Daily monitoring & optimization",
        "Dedicated account manager",
        "Creative production support",
        "Priority support (24/7)"
      ],
      buttonText: "Start Now",
      buttonClass: "bg-black text-white hover:bg-gray-800"
    }
  ];

  return (
    <section id="packages" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-black mb-4">
            Choose Your <span className="text-yellow-400">Package</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Flexible packages designed to fit businesses of all sizes. All packages include performance tracking and optimization.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {packages.map((pkg, index) => (
            <div key={index} className={`relative rounded-2xl p-8 transition-all duration-300 ${
              pkg.popular 
                ? 'bg-yellow-400 text-black transform scale-105 shadow-2xl' 
                : 'bg-white border-2 border-gray-200 hover:border-yellow-400'
            }`}>
              {pkg.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-black text-white px-6 py-2 rounded-full text-sm font-medium">Most Popular</span>
                </div>
              )}
              
              <div className={`text-center mb-8 ${pkg.popular ? 'mt-4' : ''}`}>
                <h3 className={`text-2xl font-bold mb-2 ${pkg.popular ? 'text-black' : 'text-black'}`}>
                  {pkg.name}
                </h3>
                <p className={`mb-4 ${pkg.popular ? 'text-black' : 'text-gray-600'}`}>
                  {pkg.description}
                </p>
                <div className={`text-4xl font-bold ${pkg.popular ? 'text-black' : 'text-black'}`}>
                  {pkg.price}
                </div>
                <div className={`text-sm ${pkg.popular ? 'text-black' : 'text-gray-600'}`}>
                  {pkg.period}
                </div>
              </div>
              
              <ul className="space-y-4 mb-8">
                {pkg.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center">
                    <Check className={`h-5 w-5 mr-3 ${pkg.popular ? 'text-green-700' : 'text-green-500'}`} />
                    <span className={pkg.popular ? 'text-black' : 'text-gray-700'}>{feature}</span>
                  </li>
                ))}
              </ul>
              
              <Button className={`w-full py-4 font-semibold transition-colors duration-300 ${pkg.buttonClass}`}>
                {pkg.buttonText}
              </Button>
            </div>
          ))}
        </div>
        
        {/* Custom Plan Option */}
        <div className="mt-12 text-center bg-gray-50 p-8 rounded-2xl">
          <h3 className="text-2xl font-bold text-black mb-4">
            Need a Custom Plan?
          </h3>
          <p className="text-gray-600 mb-6">
            Every business is unique. Let's create a plan that fits your specific needs and budget requirements.
          </p>
          <Button className="bg-yellow-400 text-black px-8 py-4 font-semibold hover:bg-yellow-500 transition-colors duration-300">
            Request Custom Plan
          </Button>
        </div>
      </div>
    </section>
  );
}
