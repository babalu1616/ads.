import { Button } from "@/components/ui/button";

export default function AboutSection() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <img 
              src="https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Modern digital marketing office workspace" 
              className="rounded-2xl shadow-xl w-full" 
            />
          </div>
          
          <div>
            <h2 className="text-4xl font-bold text-black mb-6">
              About <span className="text-yellow-400">DigiunixAds</span>
            </h2>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              Founded with a mission to democratize digital marketing success, DigiunixAds specializes in creating high-ROI advertising campaigns that drive real business growth.
            </p>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Our team of certified advertising experts has generated over ₹2 crores in revenue for our clients across diverse industries including real estate, healthcare, coaching, and local services.
            </p>
            
            <div className="grid grid-cols-2 gap-6 mb-8">
              <div className="text-center p-4 bg-gray-50 rounded-xl">
                <div className="text-3xl font-bold text-black">100+</div>
                <div className="text-sm text-gray-600">Happy Clients</div>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-xl">
                <div className="text-3xl font-bold text-black">₹2Cr+</div>
                <div className="text-sm text-gray-600">Revenue Generated</div>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-xl">
                <div className="text-3xl font-bold text-black">5000+</div>
                <div className="text-sm text-gray-600">Leads Delivered</div>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-xl">
                <div className="text-3xl font-bold text-black">98%</div>
                <div className="text-sm text-gray-600">Client Retention</div>
              </div>
            </div>
            
            <Button className="bg-black text-white px-8 py-4 font-semibold hover:bg-gray-800 transition-all duration-300 transform hover:scale-105">
              Learn More About Us
              <span className="ml-2">→</span>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
