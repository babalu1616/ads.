import { Button } from "@/components/ui/button";

export default function CaseStudiesSection() {
  const caseStudies = [
    {
      category: "Real Estate",
      categoryColor: "bg-blue-100 text-blue-800",
      title: "₹2.5 Cr Revenue in 8 Months",
      description: "Sai Palace Residency, Pune struggled with selling 150+ premium flats. Our targeted Meta Ads campaign focused on high-income families aged 28-45 with interest in luxury housing. Result: 180 flat bookings worth ₹2.5 Cr.",
      metrics: [
        { value: "180", label: "Flat Bookings" },
        { value: "₹14K", label: "Cost Per Lead" },
        { value: "₹2.5Cr", label: "Total Revenue" }
      ],
      image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      imageAlt: "Luxury residential building complex with modern architecture"
    },
    {
      category: "Healthcare",
      categoryColor: "bg-green-100 text-green-800",
      title: "450+ Patient Appointments",
      description: "Dr. Mehta's Multi-Specialty Clinic, Mumbai needed more patient bookings. Our Google Ads targeted local searches + Facebook campaigns for health services. Generated 450+ quality appointments with ₹12 cost per lead.",
      metrics: [
        { value: "450+", label: "Appointments" },
        { value: "₹12", label: "Cost Per Lead" },
        { value: "380%", label: "ROI Increase" }
      ],
      image: "https://images.unsplash.com/photo-1631815589968-fdb09a223b1e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      imageAlt: "Modern medical clinic interior with professional healthcare setup",
      reverse: true
    },
    {
      category: "Business Coaching",
      categoryColor: "bg-purple-100 text-purple-800",
      title: "₹85K to ₹12L Monthly Revenue",
      description: "Rajesh Sharma, Business Coach from Delhi wanted to scale his coaching business. Our YouTube Ads + Instagram campaigns targeting entrepreneurs resulted in 850+ course enrollments generating ₹12L monthly revenue.",
      metrics: [
        { value: "1400%", label: "Revenue Growth" },
        { value: "850+", label: "Course Sales" },
        { value: "₹12L", label: "Monthly Revenue" }
      ],
      image: "https://images.unsplash.com/photo-1556761175-5973dc0f32e7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      imageAlt: "Professional business coach presenting to engaged corporate audience"
    },
    {
      category: "Interior Design",
      categoryColor: "bg-orange-100 text-orange-800",
      title: "₹75L Projects in 5 Months",
      description: "Elegance Interiors, Bangalore struggled to find high-budget clients. Our Meta Ads targeting premium home buyers + Google Ads for luxury interior keywords generated 45+ project inquiries worth ₹75L total value.",
      metrics: [
        { value: "45+", label: "Premium Projects" },
        { value: "₹75L", label: "Project Value" },
        { value: "320%", label: "Lead Quality" }
      ],
      image: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      imageAlt: "Luxury modern interior design showcase with elegant furniture"
    }
  ];

  return (
    <section id="case-studies" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-black mb-4">
            Success <span className="text-yellow-400">Stories</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Real businesses, real results. See how we've helped our clients achieve extraordinary growth.
          </p>
        </div>
        
        <div className="space-y-16">
          {caseStudies.map((study, index) => (
            <div key={index} className="bg-white rounded-2xl overflow-hidden shadow-2xl hover:shadow-3xl transition-all duration-300">
              <div className={`grid lg:grid-cols-2 gap-0 ${study.reverse ? 'lg:grid-flow-col-dense' : ''}`}>
                {/* Image Section */}
                <div className={`relative overflow-hidden ${study.reverse ? 'lg:col-start-2' : ''}`}>
                  <img 
                    src={study.image}
                    alt={study.imageAlt}
                    className="w-full h-full object-cover min-h-[400px] lg:min-h-[500px]"
                  />
                  <div className="absolute top-6 left-6">
                    <span className={`${study.categoryColor} px-4 py-2 rounded-full text-sm font-semibold`}>
                      {study.category}
                    </span>
                  </div>
                </div>
                
                {/* Content Section */}
                <div className={`p-8 lg:p-12 flex flex-col justify-center ${study.reverse ? 'lg:col-start-1' : ''}`}>
                  <h3 className="text-3xl lg:text-4xl font-bold text-black mb-6">
                    {study.title}
                  </h3>
                  
                  <p className="text-lg text-gray-700 mb-8 leading-relaxed">
                    {study.description}
                  </p>
                  
                  <div className="grid grid-cols-3 gap-6 mb-8">
                    {study.metrics.map((metric, metricIndex) => (
                      <div key={metricIndex} className="text-center">
                        <div className="text-2xl lg:text-3xl font-bold text-yellow-400 mb-2">
                          {metric.value}
                        </div>
                        <div className="text-sm text-gray-600 font-medium">
                          {metric.label}
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <a 
                    href="/case-study-detail" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-block"
                  >
                    <Button className="bg-black text-white hover:bg-gray-800 px-8 py-3 w-fit font-semibold">
                      View Full Case Study
                    </Button>
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* CTA Section */}
        <div className="mt-20 bg-black rounded-2xl p-8 lg:p-12 text-center">
          <h3 className="text-3xl font-bold text-white mb-4">
            Ready to Be Our Next Success Story?
          </h3>
          <p className="text-gray-300 text-lg mb-8 max-w-3xl mx-auto">
            Join 50+ businesses that have transformed their growth with our proven advertising strategies. Get a custom plan for your industry.
          </p>
          <Button className="bg-yellow-400 text-black hover:bg-yellow-500 px-8 py-3 font-semibold text-lg">
            Get Your Custom Strategy
          </Button>
        </div>
      </div>
    </section>
  );
}