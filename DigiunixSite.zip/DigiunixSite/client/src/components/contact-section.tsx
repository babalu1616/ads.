import { useState } from "react";
import { CalendarCheck, ChartLine, Rocket, Phone, Mail, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { InsertContact } from "@shared/schema";

export default function ContactSection() {
  const { toast } = useToast();
  const [formData, setFormData] = useState<InsertContact>({
    name: "",
    phone: "",
    email: "",
    businessType: "",
    budget: "",
    message: ""
  });

  const submitContactMutation = useMutation({
    mutationFn: async (data: InsertContact) => {
      const response = await apiRequest("POST", "/api/contacts", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Form submitted successfully!",
        description: "We'll contact you within 24 hours to schedule your free strategy call.",
      });
      setFormData({
        name: "",
        phone: "",
        email: "",
        businessType: "",
        budget: "",
        message: ""
      });
    },
    onError: (error) => {
      toast({
        title: "Submission failed",
        description: "Please check your information and try again.",
        variant: "destructive",
      });
      console.error("Contact form error:", error);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone || !formData.email || !formData.businessType || !formData.budget) {
      toast({
        title: "Missing required fields",
        description: "Please fill in all required fields marked with *",
        variant: "destructive",
      });
      return;
    }
    submitContactMutation.mutate(formData);
  };

  const updateFormData = (field: keyof InsertContact, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <section id="contact" className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-4xl font-bold text-white mb-6">
              Ready to Scale Your Business?
            </h2>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              Book a free 30-minute strategy call and discover how we can generate quality leads for your business through proven advertising strategies.
            </p>
            
            <div className="space-y-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-yellow-400 rounded-full flex items-center justify-center mr-4">
                  <CalendarCheck className="text-black" />
                </div>
                <div>
                  <h4 className="font-semibold text-white">Free Strategy Session</h4>
                  <p className="text-gray-300">30-minute consultation to analyze your current marketing</p>
                </div>
              </div>
              
              <div className="flex items-center">
                <div className="w-12 h-12 bg-yellow-400 rounded-full flex items-center justify-center mr-4">
                  <ChartLine className="text-black" />
                </div>
                <div>
                  <h4 className="font-semibold text-white">Custom Strategy</h4>
                  <p className="text-gray-300">Tailored advertising plan for your specific business goals</p>
                </div>
              </div>
              
              <div className="flex items-center">
                <div className="w-12 h-12 bg-yellow-400 rounded-full flex items-center justify-center mr-4">
                  <Rocket className="text-black" />
                </div>
                <div>
                  <h4 className="font-semibold text-white">Fast Implementation</h4>
                  <p className="text-gray-300">Start seeing results within 7-14 days of campaign launch</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-2xl p-8 shadow-2xl">
            <h3 className="text-2xl font-bold text-black mb-6 text-center">
              Get Your Free Strategy Call
            </h3>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label className="block text-sm font-medium text-gray-700 mb-2">Full Name *</Label>
                  <Input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => updateFormData("name", e.target.value)}
                    placeholder="Enter your full name"
                    className="w-full"
                  />
                </div>
                <div>
                  <Label className="block text-sm font-medium text-gray-700 mb-2">Phone Number *</Label>
                  <Input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => updateFormData("phone", e.target.value)}
                    placeholder="9685696548"
                    className="w-full"
                  />
                </div>
              </div>
              
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-2">Email Address *</Label>
                <Input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => updateFormData("email", e.target.value)}
                  placeholder="digiunixads@gmail.com"
                  className="w-full"
                />
              </div>
              
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-2">Business Type *</Label>
                <Select value={formData.businessType} onValueChange={(value) => updateFormData("businessType", value)} required>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select your business type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="real-estate">Real Estate</SelectItem>
                    <SelectItem value="interior-design">Interior Design</SelectItem>
                    <SelectItem value="healthcare">Healthcare/Clinic</SelectItem>
                    <SelectItem value="coaching">Coaching/Training</SelectItem>
                    <SelectItem value="local-services">Local Services</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-2">Monthly Ad Budget *</Label>
                <Select value={formData.budget} onValueChange={(value) => updateFormData("budget", value)} required>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select your budget range" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="25000-50000">₹25,000 - ₹50,000</SelectItem>
                    <SelectItem value="50000-100000">₹50,000 - ₹1,00,000</SelectItem>
                    <SelectItem value="100000-250000">₹1,00,000 - ₹2,50,000</SelectItem>
                    <SelectItem value="250000-500000">₹2,50,000 - ₹5,00,000</SelectItem>
                    <SelectItem value="500000+">₹5,00,000+</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-2">Tell us about your goals (Optional)</Label>
                <Textarea
                  rows={4}
                  value={formData.message || ""}
                  onChange={(e) => updateFormData("message", e.target.value)}
                  placeholder="What are your main business objectives? What challenges are you facing with lead generation?"
                  className="w-full"
                />
              </div>

              {/* Contact Information */}
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <div className="grid grid-cols-1 gap-3 text-sm text-gray-700">
                  <div className="flex items-center justify-center space-x-2">
                    <Phone className="w-4 h-4 text-yellow-600" />
                    <span className="font-medium">+91 9685696548</span>
                  </div>
                  <div className="flex items-center justify-center space-x-2">
                    <Mail className="w-4 h-4 text-yellow-600" />
                    <span className="font-medium">digiunixads@gmail.com</span>
                  </div>
                  <div className="flex items-center justify-center space-x-2">
                    <MapPin className="w-4 h-4 text-yellow-600" />
                    <span className="font-medium">Kota, Rajasthan | Ratlam, MP</span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <Button
                  type="submit"
                  disabled={submitContactMutation.isPending}
                  className="w-full bg-yellow-400 text-black py-4 text-lg font-bold hover:bg-yellow-500 transition-all duration-300 transform hover:scale-105"
                >
                  <CalendarCheck className="mr-2 h-5 w-5" />
                  {submitContactMutation.isPending ? "Submitting..." : "Book My Free Strategy Call"}
                </Button>

                <div className="text-center">
                  <p className="text-sm text-gray-600 mb-3">Or schedule directly:</p>
                  <Button
                    type="button"
                    onClick={() => window.open("https://calendly.com/digiunixads/30min", "_blank")}
                    variant="outline"
                    className="w-full border-2 border-yellow-400 text-yellow-600 hover:bg-yellow-400 hover:text-black py-3 text-lg font-semibold transition-all duration-300"
                  >
                    <CalendarCheck className="mr-2 h-5 w-5" />
                    Direct Meeting Booking
                  </Button>
                </div>
              </div>
              
              <p className="text-xs text-gray-500 text-center">
                By submitting this form, you agree to our 
                <a href="#" className="text-yellow-600 hover:underline ml-1">privacy policy</a> and 
                <a href="#" className="text-yellow-600 hover:underline ml-1">terms of service</a>.
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
