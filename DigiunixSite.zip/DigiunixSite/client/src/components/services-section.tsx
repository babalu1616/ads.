import { Facebook, Youtube, Chrome, Check } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ServicesSection() {
  const services = [
    {
      icon: <Facebook className="text-3xl text-blue-600" />,
      title: "Meta Ads",
      description: "Facebook & Instagram advertising campaigns designed to capture high-intent prospects and convert them into paying customers.",
      features: [
        "Advanced audience targeting",
        "Creative optimization",
        "ROI tracking & optimization"
      ],
      color: "bg-blue-600 hover:bg-blue-700"
    },
    {
      icon: <Chrome className="text-3xl text-red-600" />,
      title: "Google Ads",
      description: "Search, Display, and Shopping campaigns that put your business in front of customers actively searching for your services.",
      features: [
        "Keyword research & optimization",
        "Landing page optimization",
        "Quality Score improvement"
      ],
      color: "bg-red-600 hover:bg-red-700"
    },
    {
      icon: <Youtube className="text-3xl text-red-600" />,
      title: "YouTube Ads",
      description: "Video advertising campaigns that engage your audience with compelling storytelling and drive action through visual content.",
      features: [
        "Video production guidance",
        "Audience targeting",
        "Performance optimization"
      ],
      color: "bg-red-600 hover:bg-red-700"
    }
  ];

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-black mb-4">
            Our Core <span className="text-yellow-400">Services</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We specialize in three powerful advertising platforms to maximize your business growth and lead generation
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div key={index} className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
              <div className="w-16 h-16 bg-blue-100 rounded-xl flex items-center justify-center mb-6">
                {service.icon}
              </div>
              <h3 className="text-2xl font-bold text-black mb-4">{service.title}</h3>
              <p className="text-gray-600 mb-6 leading-relaxed">
                {service.description}
              </p>
              <ul className="space-y-2 mb-6">
                {service.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center text-sm text-gray-600">
                    <Check className="h-4 w-4 text-green-500 mr-2" />
                    {feature}
                  </li>
                ))}
              </ul>
              <Button className={`w-full text-white py-3 font-semibold transition-colors duration-300 ${service.color}`}>
                Learn More
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
