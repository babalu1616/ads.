import { Calendar, User, ArrowRight, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function BlogSection() {
  const blogs = [
    {
      title: "Facebook Ads vs Google Ads: Which is Better for Real Estate in 2024?",
      excerpt: "Complete comparison of Facebook Ads and Google Ads for real estate lead generation. Learn which platform delivers better ROI for property developers.",
      author: "DigiunixAds Team",
      date: "Dec 15, 2024",
      readTime: "8 min read",
      category: "Real Estate Marketing",
      image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      keywords: ["facebook ads real estate", "google ads property", "real estate lead generation"]
    },
    {
      title: "Complete Guide to Google Ads for Clinics and Healthcare Centers",
      excerpt: "Step-by-step guide to create profitable Google Ads campaigns for medical practices. Increase patient appointments by 300% with these strategies.",
      author: "Dr. Marketing Expert",
      date: "Dec 12, 2024", 
      readTime: "12 min read",
      category: "Healthcare Marketing",
      image: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      keywords: ["google ads for doctors", "medical marketing", "healthcare advertising"]
    },
    {
      title: "YouTube Ads for Coaches: How to Get 1000+ Course Sales in 90 Days",
      excerpt: "Proven YouTube advertising strategies for business coaches. Learn the exact video ad formats and targeting that generate maximum course enrollments.",
      author: "Coach Success Team",
      date: "Dec 10, 2024",
      readTime: "10 min read", 
      category: "Coaching Business",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      keywords: ["youtube ads for coaches", "coaching business marketing", "online course promotion"]
    },
    {
      title: "Instagram Ads for Interior Designers: Generate High-Value Clients",
      excerpt: "Master Instagram advertising for interior design businesses. Attract premium clients willing to pay ₹5L+ for luxury home projects.",
      author: "Design Marketing Pro",
      date: "Dec 8, 2024",
      readTime: "9 min read",
      category: "Interior Design",
      image: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400", 
      keywords: ["instagram ads interior design", "luxury interior marketing", "home design advertising"]
    },
    {
      title: "Local Business Marketing: Meta Ads Strategy That Actually Works",
      excerpt: "Practical Meta Ads strategies for local service businesses. Increase foot traffic and local customers by 250% with location-based targeting.",
      author: "Local Marketing Expert",
      date: "Dec 5, 2024",
      readTime: "7 min read",
      category: "Local Business",
      image: "https://images.unsplash.com/photo-1556761175-4b46a572b786?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      keywords: ["local business advertising", "meta ads local", "facebook ads for local business"]
    },
    {
      title: "Google Search Ads Optimization: Reduce Cost Per Lead by 60%",
      excerpt: "Advanced Google Search Ads optimization techniques. Learn quality score improvement, keyword bidding strategies, and ad copy that converts.",
      author: "PPC Specialist",
      date: "Dec 3, 2024",
      readTime: "11 min read",
      category: "Google Ads",
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      keywords: ["google search ads", "ppc optimization", "cost per lead reduction"]
    },
    {
      title: "Facebook Lead Generation Ads: Complete Setup Guide for 2024",
      excerpt: "Master Facebook Lead Generation campaigns. Setup, optimization, and advanced targeting strategies to generate 500+ quality leads monthly.",
      author: "Lead Gen Expert", 
      date: "Nov 30, 2024",
      readTime: "13 min read",
      category: "Lead Generation",
      image: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      keywords: ["facebook lead ads", "lead generation strategy", "facebook advertising"]
    },
    {
      title: "YouTube Video Marketing for Small Businesses: ROI-Focused Approach",
      excerpt: "Create profitable YouTube video marketing campaigns for small businesses. Learn content strategies that generate 10x ROI and viral reach.",
      author: "Video Marketing Pro",
      date: "Nov 28, 2024", 
      readTime: "8 min read",
      category: "Video Marketing",
      image: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      keywords: ["youtube marketing", "video advertising", "small business youtube"]
    },
    {
      title: "Conversion Rate Optimization for Landing Pages: 15 Proven Techniques",
      excerpt: "Increase landing page conversions by 400% with these proven CRO techniques. A/B testing strategies, design principles, and psychological triggers.",
      author: "CRO Specialist",
      date: "Nov 25, 2024",
      readTime: "14 min read", 
      category: "Conversion Optimization",
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      keywords: ["conversion rate optimization", "landing page optimization", "cro techniques"]
    },
    {
      title: "Digital Marketing ROI Calculator: Measure Campaign Success Like a Pro",
      excerpt: "Complete guide to measuring digital marketing ROI. Track ROAS, CAC, LTV and other key metrics to optimize your advertising spend effectively.",
      author: "Analytics Expert",
      date: "Nov 22, 2024",
      readTime: "10 min read",
      category: "Analytics & ROI", 
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      keywords: ["digital marketing roi", "marketing analytics", "advertising metrics"]
    }
  ];

  return (
    <section id="blog" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-black mb-4">
            Latest <span className="text-yellow-400">Marketing</span> Insights
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Stay ahead with our expert insights on digital marketing, advertising strategies, and industry trends.
          </p>
        </div>
        
        {/* Featured Blog */}
        <div className="mb-16">
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div className="grid lg:grid-cols-2 gap-0">
              <div className="relative">
                <img 
                  src={blogs[0].image}
                  alt={blogs[0].title}
                  className="w-full h-full object-cover min-h-[300px]"
                />
                <div className="absolute top-4 left-4">
                  <span className="bg-yellow-400 text-black px-3 py-1 rounded-full text-sm font-medium">
                    Featured
                  </span>
                </div>
              </div>
              <div className="p-8 lg:p-12 flex flex-col justify-center">
                <div className="mb-4">
                  <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                    {blogs[0].category}
                  </span>
                </div>
                <h3 className="text-2xl lg:text-3xl font-bold text-black mb-4">
                  {blogs[0].title}
                </h3>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  {blogs[0].excerpt}
                </p>
                <div className="flex items-center text-sm text-gray-500 mb-6">
                  <User className="w-4 h-4 mr-2" />
                  <span className="mr-4">{blogs[0].author}</span>
                  <Calendar className="w-4 h-4 mr-2" />
                  <span className="mr-4">{blogs[0].date}</span>
                  <span>{blogs[0].readTime}</span>
                </div>
                <a 
                  href="/blog-detail" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-block"
                >
                  <Button className="bg-black text-white hover:bg-gray-800 w-fit">
                    Read Full Article <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </a>
              </div>
            </div>
          </div>
        </div>
        
        {/* Blog Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogs.slice(1).map((blog, index) => (
            <article key={index} className="bg-white rounded-2xl shadow-lg overflow-hidden group hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
              <div className="relative overflow-hidden">
                <img 
                  src={blog.image}
                  alt={blog.title}
                  className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute top-4 left-4">
                  <span className="bg-white/90 text-black px-3 py-1 rounded-full text-xs font-medium">
                    {blog.category}
                  </span>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-lg font-bold text-black mb-3 line-clamp-2 group-hover:text-yellow-600 transition-colors">
                  {blog.title}
                </h3>
                <p className="text-gray-600 text-sm mb-4 line-clamp-3">
                  {blog.excerpt}
                </p>
                
                <div className="flex items-center text-xs text-gray-500 mb-4">
                  <User className="w-3 h-3 mr-1" />
                  <span className="mr-3">{blog.author}</span>
                  <Calendar className="w-3 h-3 mr-1" />
                  <span className="mr-3">{blog.date}</span>
                  <span>{blog.readTime}</span>
                </div>
                
                <a 
                  href="/blog-detail" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-block"
                >
                  <Button 
                    variant="ghost" 
                    className="text-black hover:text-yellow-600 p-0 font-medium"
                  >
                    Read More <ArrowRight className="ml-1 w-4 h-4" />
                  </Button>
                </a>
              </div>
            </article>
          ))}
        </div>
        
        {/* CTA Section */}
        <div className="mt-16 text-center bg-black rounded-2xl p-8">
          <TrendingUp className="w-12 h-12 text-yellow-400 mx-auto mb-4" />
          <h3 className="text-2xl font-bold text-white mb-4">
            Want More Marketing Insights?
          </h3>
          <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
            Subscribe to our newsletter and get the latest digital marketing strategies, case studies, and industry updates delivered to your inbox.
          </p>
          <Button className="bg-yellow-400 text-black hover:bg-yellow-500 px-8 py-3 font-semibold">
            Subscribe Now
          </Button>
        </div>
      </div>
    </section>
  );
}