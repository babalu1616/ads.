import { Star, User } from "lucide-react";

export default function ResultsSection() {
  const metrics = [
    { value: "₹2Cr+", label: "Revenue Generated", gradient: "from-yellow-400 to-yellow-500" },
    { value: "5000+", label: "Leads Delivered", gradient: "from-green-500 to-green-600" },
    { value: "300%", label: "Average ROI", gradient: "from-blue-500 to-blue-600" },
    { value: "100+", label: "Happy Clients", gradient: "from-purple-500 to-purple-600" }
  ];

  const testimonials = [
    {
      name: "Rajesh Kumar",
      company: "Real Estate Developer",
      review: "DigiunixAds transformed our lead generation. We went from 10 leads per month to 150+ quality leads through their Meta Ads campaigns. ROI increased by 280%!"
    },
    {
      name: "Dr. Priya Sharma",
      company: "Dental Clinic Owner",
      review: "Google Ads campaigns by DigiunixAds brought us 200+ patient appointments in 3 months. Their targeting strategy is incredibly precise and cost-effective."
    },
    {
      name: "Amit Verma",
      company: "Business Coach",
      review: "YouTube Ads created by DigiunixAds helped me scale my coaching business from ₹50K to ₹5L monthly revenue. Their video optimization is outstanding!"
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-black mb-4">
            Proven <span className="text-yellow-400">Results</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Don't just take our word for it. Here's what our clients have achieved with our advertising strategies.
          </p>
        </div>
        
        {/* Results Metrics */}
        <div className="grid md:grid-cols-4 gap-6 mb-16">
          {metrics.map((metric, index) => (
            <div key={index} className={`text-center p-6 bg-gradient-to-br ${metric.gradient} rounded-2xl text-white`}>
              <div className="text-4xl font-bold mb-2">{metric.value}</div>
              <div className="font-medium">{metric.label}</div>
            </div>
          ))}
        </div>
        
        {/* Testimonials */}
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-gray-50 p-8 rounded-2xl shadow-lg">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-yellow-400 rounded-full flex items-center justify-center mr-4">
                  <User className="text-black" />
                </div>
                <div>
                  <h4 className="font-semibold text-black">{testimonial.name}</h4>
                  <p className="text-sm text-gray-600">{testimonial.company}</p>
                </div>
              </div>
              <div className="flex mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                ))}
              </div>
              <p className="text-gray-700 italic">"{testimonial.review}"</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
