import { Trophy, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function PerformanceBasedSection() {
  const revenueSlabs = [
    { range: "₹0 - ₹10L", share: "10%" },
    { range: "₹10L - ₹25L", share: "15%" },
    { range: "₹25L - ₹50L", share: "20%" },
    { range: "₹50L+", share: "25%" }
  ];

  const scrollToContact = () => {
    const element = document.querySelector("#contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="py-20 bg-gradient-to-br from-yellow-400 to-orange-500">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="w-16 h-16 bg-black rounded-full flex items-center justify-center mx-auto mb-6">
            <Trophy className="w-8 h-8 text-yellow-400" />
          </div>
          <h2 className="text-4xl font-bold text-black mb-4">
            We Only Win When You Win
          </h2>
          <p className="text-xl text-black max-w-3xl mx-auto">
            Get our premium services with monthly fees PLUS earn extra performance bonuses based on the revenue we generate for your business.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h3 className="text-2xl font-bold text-black mb-6">Extra Performance Bonus Structure</h3>
            <div className="bg-white rounded-2xl p-8 shadow-xl">
              <div className="space-y-4">
                {revenueSlabs.map((slab, index) => (
                  <div key={index} className="flex justify-between items-center p-4 bg-gray-50 rounded-xl">
                    <div className="font-semibold text-black">{slab.range}</div>
                    <div className="text-2xl font-bold text-yellow-600">{slab.share}</div>
                  </div>
                ))}
              </div>
              <div className="mt-6 p-4 bg-yellow-100 rounded-xl">
                <p className="text-sm text-black font-medium">
                  💡 Monthly service fees apply as per your chosen package + extra performance bonus based on revenue generated.
                </p>
              </div>
            </div>
          </div>
          
          <div className="text-center lg:text-left">
            <TrendingUp className="w-20 h-20 text-black mx-auto lg:mx-0 mb-6" />
            <h3 className="text-3xl font-bold text-black mb-6">
              Guaranteed Service + Performance Rewards
            </h3>
            <ul className="space-y-4 text-black mb-8">
              <li className="flex items-center">
                <div className="w-2 h-2 bg-black rounded-full mr-3"></div>
                Monthly service fees as per package
              </li>
              <li className="flex items-center">
                <div className="w-2 h-2 bg-black rounded-full mr-3"></div>
                Extra bonus on revenue generated
              </li>
              <li className="flex items-center">
                <div className="w-2 h-2 bg-black rounded-full mr-3"></div>
                Complete transparency in reporting
              </li>
              <li className="flex items-center">
                <div className="w-2 h-2 bg-black rounded-full mr-3"></div>
                Dedicated account management
              </li>
            </ul>
            <Button
              onClick={scrollToContact}
              className="bg-black text-yellow-400 px-8 py-4 text-lg font-semibold hover:bg-gray-800 transition-all duration-300 transform hover:scale-105"
            >
              Discuss Custom Plan
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}