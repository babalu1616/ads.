import { Building, Stethoscope, PaintBucket, GraduationCap, Store } from "lucide-react";

export default function TargetNichesSection() {
  const niches = [
    {
      icon: <Building className="w-12 h-12" />,
      title: "Real Estate",
      subtitle: "Builders & Developers"
    },
    {
      icon: <Stethoscope className="w-12 h-12" />,
      title: "Clinics",
      subtitle: "Healthcare Providers"
    },
    {
      icon: <PaintBucket className="w-12 h-12" />,
      title: "Interior Designers",
      subtitle: "Home & Office Spaces"
    },
    {
      icon: <GraduationCap className="w-12 h-12" />,
      title: "Coaches",
      subtitle: "Business & Life Coaches"
    },
    {
      icon: <Store className="w-12 h-12" />,
      title: "Local D2C Brands",
      subtitle: "Service Businesses"
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-black mb-4">
            Industries We <span className="text-yellow-400">Specialize In</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            We understand the unique challenges of these industries and create targeted campaigns that deliver results.
          </p>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
          {niches.map((niche, index) => (
            <div key={index} className="text-center group cursor-pointer">
              <div className="w-20 h-20 bg-yellow-400 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:bg-black group-hover:text-yellow-400 transition-all duration-300 transform group-hover:scale-110">
                {niche.icon}
              </div>
              <h3 className="font-semibold text-black mb-1">{niche.title}</h3>
              <p className="text-sm text-gray-600">{niche.subtitle}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}