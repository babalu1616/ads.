import { Calendar, ChartLine, Star, Trophy, Users } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function HeroSection() {
  const scrollToContact = () => {
    const element = document.querySelector("#contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const scrollToCaseStudies = () => {
    const element = document.querySelector("#case-studies");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="home" className="relative bg-gradient-to-br from-black via-gray-800 to-black min-h-screen flex items-center pt-16">
      <div className="absolute inset-0 bg-black opacity-60"></div>
      <div 
        className="absolute inset-0" 
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')",
          backgroundSize: "cover",
          backgroundPosition: "center"
        }}
      ></div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left animate-in slide-in-from-bottom-8 duration-1000">
            <h1 className="text-4xl md:text-6xl font-bold text-white leading-tight mb-6">
              Get More Leads, Clients & Sales with Our
              <span className="block bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
                Done-For-You Ads
              </span>
            </h1>
            <p className="text-xl text-gray-300 mb-8 max-w-2xl">
              We handle everything – creatives, campaigns, landing pages & more for real estate builders, interior designers, clinics, and coaches.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-8">
              <Button
                onClick={scrollToContact}
                className="bg-yellow-400 text-black px-8 py-4 text-lg font-semibold hover:bg-yellow-500 transition-all duration-300 transform hover:scale-105 shadow-2xl"
              >
                <Calendar className="mr-2 h-5 w-5" />
                Book Free Strategy Call
              </Button>
              <Button
                onClick={scrollToCaseStudies}
                variant="outline"
                className="border-2 border-white text-white px-8 py-4 text-lg font-semibold hover:bg-white hover:text-black transition-all duration-300 transform hover:scale-105"
              >
                <ChartLine className="mr-2 h-5 w-5" />
                View Case Studies
              </Button>
            </div>
            
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-6 text-sm text-gray-300">
              <div className="flex items-center">
                <Star className="h-5 w-5 text-yellow-400 mr-1" />
                <span className="font-medium">4.9/5 Google Rating</span>
              </div>
              <div className="flex items-center">
                <Trophy className="h-5 w-5 text-yellow-400 mr-1" />
                <span className="font-medium">₹2 Cr+ Revenue Generated</span>
              </div>
              <div className="flex items-center">
                <Users className="h-5 w-5 text-yellow-400 mr-1" />
                <span className="font-medium">5000+ Leads Delivered</span>
              </div>
            </div>
          </div>
          
          <div className="lg:flex justify-center hidden">
            <img 
              src="https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Professional marketing consultation" 
              className="rounded-2xl shadow-2xl w-full max-w-lg animate-in slide-in-from-right-8 duration-1000 delay-300" 
            />
          </div>
        </div>
      </div>
    </section>
  );
}
