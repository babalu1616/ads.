import { Shield, Award, Handshake, Star } from "lucide-react";
import { SiGoogle } from "react-icons/si";

export default function TrustElementsSection() {
  const trustElements = [
    {
      icon: <SiGoogle className="text-3xl text-red-500" />,
      title: "Google Verified",
      subtitle: "4.9/5 Rating (150+ Reviews)",
      stars: true
    },
    {
      icon: <Shield className="text-3xl text-green-500" />,
      title: "100% Secure",
      subtitle: "SSL Encrypted & Privacy Protected"
    },
    {
      icon: <Award className="text-3xl text-purple-500" />,
      title: "Certified Experts",
      subtitle: "Google & Meta Certified Team"
    },
    {
      icon: <Handshake className="text-3xl text-blue-500" />,
      title: "Money Back Guarantee",
      subtitle: "30-Day Performance Guarantee"
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-black mb-4">
            Trusted by Businesses Across India
          </h2>
        </div>
        
        <div className="grid md:grid-cols-4 gap-8">
          {trustElements.map((element, index) => (
            <div key={index} className="text-center">
              <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                {element.icon}
              </div>
              <h4 className="font-semibold text-black mb-2">{element.title}</h4>
              {element.stars && (
                <div className="flex justify-center mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                  ))}
                </div>
              )}
              <p className="text-sm text-gray-600">{element.subtitle}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
