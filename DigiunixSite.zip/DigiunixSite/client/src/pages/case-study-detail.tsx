import { ArrowLeft, Calendar, MapPin, Phone, Mail, TrendingUp, Users, Target } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

export default function CaseStudyDetail() {
  const [, setLocation] = useLocation();
  
  const caseStudy = {
    category: "Real Estate",
    categoryColor: "bg-blue-100 text-blue-800",
    title: "₹2.5 Cr Revenue in 8 Months",
    subtitle: "Sai Palace Residency, Pune",
    description: "How we helped a luxury residential project sell 180+ premium flats through strategic Meta Ads campaigns",
    image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=600",
    duration: "8 months",
    location: "Pune, Maharashtra"
  };

  const handleBackClick = () => {
    setLocation('/');
    setTimeout(() => {
      const caseStudiesSection = document.getElementById('case-studies');
      if (caseStudiesSection) {
        caseStudiesSection.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Button 
            variant="ghost" 
            className="mb-6 text-gray-600 hover:text-black"
            onClick={handleBackClick}
          >
            <ArrowLeft className="mr-2 w-4 h-4" />
            Back to Case Studies
          </Button>
          
          <div className="mb-6">
            <span className={`${caseStudy.categoryColor} px-3 py-1 rounded-full text-sm font-medium`}>
              {caseStudy.category}
            </span>
          </div>
          
          <h1 className="text-4xl lg:text-5xl font-bold text-black mb-4 leading-tight">
            {caseStudy.title}
          </h1>
          
          <h2 className="text-2xl text-gray-700 mb-6">
            {caseStudy.subtitle}
          </h2>
          
          <div className="flex items-center text-gray-600 mb-8 flex-wrap gap-4">
            <div className="flex items-center">
              <Calendar className="w-5 h-5 mr-2" />
              <span>{caseStudy.duration}</span>
            </div>
            <div className="flex items-center">
              <MapPin className="w-5 h-5 mr-2" />
              <span>{caseStudy.location}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Featured Image */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 -mt-16 mb-12">
        <div className="relative">
          <img 
            src={caseStudy.image}
            alt={caseStudy.title}
            className="w-full h-[400px] lg:h-[500px] object-cover rounded-2xl shadow-2xl"
          />
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        
        {/* Overview */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-black mb-6">Project Overview</h2>
          <p className="text-lg text-gray-700 leading-relaxed">
            {caseStudy.description}
          </p>
        </div>

        {/* Key Metrics */}
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <div className="bg-yellow-50 p-6 rounded-xl text-center">
            <div className="text-3xl font-bold text-yellow-600 mb-2">180</div>
            <div className="text-gray-700">Flat Bookings</div>
          </div>
          <div className="bg-green-50 p-6 rounded-xl text-center">
            <div className="text-3xl font-bold text-green-600 mb-2">₹2.5Cr</div>
            <div className="text-gray-700">Total Revenue</div>
          </div>
          <div className="bg-blue-50 p-6 rounded-xl text-center">
            <div className="text-3xl font-bold text-blue-600 mb-2">₹14K</div>
            <div className="text-gray-700">Cost Per Lead</div>
          </div>
        </div>

        {/* Challenge */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-black mb-6">The Challenge</h2>
          <div className="bg-red-50 border-l-4 border-red-400 p-6 rounded-r-xl">
            <h3 className="font-bold text-red-800 mb-3">Initial Situation</h3>
            <ul className="space-y-2 text-red-700">
              <li>• 150+ luxury flats unsold for 8+ months</li>
              <li>• Traditional marketing methods failing to attract buyers</li>
              <li>• High inventory cost mounting pressure</li>
              <li>• Competition from established developers</li>
              <li>• Limited brand awareness in target market</li>
            </ul>
          </div>
        </div>

        {/* Strategy */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-black mb-6">Our Strategy</h2>
          
          <div className="space-y-8">
            <div className="bg-blue-50 p-6 rounded-xl">
              <h3 className="text-xl font-bold text-blue-800 mb-4 flex items-center">
                <Target className="mr-2" />
                Audience Targeting
              </h3>
              <ul className="space-y-2 text-blue-700">
                <li>• High-income families (₹8L+ annual income)</li>
                <li>• Age group 28-45 years</li>
                <li>• Interested in luxury housing and real estate investment</li>
                <li>• Located within 50km radius of Pune</li>
                <li>• Recently engaged couples and growing families</li>
              </ul>
            </div>

            <div className="bg-green-50 p-6 rounded-xl">
              <h3 className="text-xl font-bold text-green-800 mb-4 flex items-center">
                <TrendingUp className="mr-2" />
                Campaign Structure
              </h3>
              <ul className="space-y-2 text-green-700">
                <li>• Brand awareness campaigns showcasing luxury lifestyle</li>
                <li>• Lead generation campaigns with virtual tour offers</li>
                <li>• Retargeting campaigns for website visitors</li>
                <li>• Video campaigns highlighting amenities and location</li>
                <li>• Lookalike audiences based on existing customer data</li>
              </ul>
            </div>

            <div className="bg-purple-50 p-6 rounded-xl">
              <h3 className="text-xl font-bold text-purple-800 mb-4 flex items-center">
                <Users className="mr-2" />
                Creative Strategy
              </h3>
              <ul className="space-y-2 text-purple-700">
                <li>• High-quality property photography and drone shots</li>
                <li>• Virtual walkthrough videos</li>
                <li>• Lifestyle-focused creative showing family moments</li>
                <li>• Testimonials from early buyers</li>
                <li>• Location advantage highlighting (schools, hospitals, connectivity)</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Results Timeline */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-black mb-6">Results Timeline</h2>
          
          <div className="space-y-6">
            <div className="border-l-4 border-yellow-400 pl-6 py-4">
              <h4 className="font-bold text-lg">Month 1-2: Foundation</h4>
              <p className="text-gray-700">Campaign setup, audience research, creative development</p>
              <p className="text-yellow-600 font-semibold">25 leads generated, 8 site visits</p>
            </div>
            
            <div className="border-l-4 border-blue-400 pl-6 py-4">
              <h4 className="font-bold text-lg">Month 3-4: Optimization</h4>
              <p className="text-gray-700">Audience refinement, creative testing, funnel optimization</p>
              <p className="text-blue-600 font-semibold">65 leads generated, 28 site visits, 12 bookings</p>
            </div>
            
            <div className="border-l-4 border-green-400 pl-6 py-4">
              <h4 className="font-bold text-lg">Month 5-6: Scaling</h4>
              <p className="text-gray-700">Budget increase, lookalike expansion, video campaigns</p>
              <p className="text-green-600 font-semibold">95 leads generated, 45 site visits, 58 bookings</p>
            </div>
            
            <div className="border-l-4 border-purple-400 pl-6 py-4">
              <h4 className="font-bold text-lg">Month 7-8: Peak Performance</h4>
              <p className="text-gray-700">Maximum ROI phase, referral campaigns, inventory clearance</p>
              <p className="text-purple-600 font-semibold">130 leads generated, 78 site visits, 110 bookings</p>
            </div>
          </div>
        </div>

        {/* Key Learnings */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-black mb-6">Key Learnings</h2>
          <div className="bg-gray-50 p-6 rounded-xl">
            <ul className="space-y-3 text-gray-700">
              <li>• <strong>Video content</strong> generated 3x higher engagement than static images</li>
              <li>• <strong>Lookalike audiences</strong> based on existing customers had 40% lower CPL</li>
              <li>• <strong>Virtual tours</strong> as lead magnets increased conversion by 65%</li>
              <li>• <strong>Weekend campaigns</strong> performed 25% better for site visit bookings</li>
              <li>• <strong>Testimonial content</strong> from early buyers built crucial social proof</li>
            </ul>
          </div>
        </div>

        {/* Contact CTA */}
        <div className="bg-black rounded-2xl p-8 text-center">
          <h3 className="text-2xl font-bold text-white mb-4">
            Want Similar Results for Your Real Estate Project?
          </h3>
          <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
            Get a free consultation and custom strategy for your property business. We'll analyze your market and create a proven plan for maximum sales.
          </p>
          
          <div className="grid md:grid-cols-3 gap-6 mb-8 text-white">
            <div className="flex items-center justify-center space-x-2">
              <Phone className="w-5 h-5 text-yellow-400" />
              <span>+91 9685696548</span>
            </div>
            <div className="flex items-center justify-center space-x-2">
              <Mail className="w-5 h-5 text-yellow-400" />
              <span>digiunixads@gmail.com</span>
            </div>
            <div className="flex items-center justify-center space-x-2">
              <MapPin className="w-5 h-5 text-yellow-400" />
              <span>Kota, Rajasthan</span>
            </div>
          </div>
          
          <Button className="bg-yellow-400 text-black hover:bg-yellow-500 px-8 py-3 font-semibold">
            Get Free Strategy Session
          </Button>
        </div>

        {/* Other Case Studies */}
        <div className="mt-16">
          <h3 className="text-2xl font-bold text-black mb-8">Other Success Stories</h3>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-gray-50 rounded-xl p-6 hover:shadow-lg transition-shadow">
              <h4 className="font-bold text-lg mb-3">Dr. Mehta's Clinic: 450+ Patient Appointments</h4>
              <p className="text-gray-600 text-sm mb-4">How we helped a Mumbai clinic generate 450+ quality patient appointments with ₹12 cost per lead using Google Ads and Facebook campaigns.</p>
              <Button variant="ghost" className="text-black hover:text-yellow-600 p-0">
                View Case Study →
              </Button>
            </div>
            <div className="bg-gray-50 rounded-xl p-6 hover:shadow-lg transition-shadow">
              <h4 className="font-bold text-lg mb-3">Business Coach: ₹85K to ₹12L Monthly Revenue</h4>
              <p className="text-gray-600 text-sm mb-4">Discover how we helped Rajesh Sharma scale his coaching business from ₹85K to ₹12L monthly revenue using YouTube and Instagram ads.</p>
              <Button variant="ghost" className="text-black hover:text-yellow-600 p-0">
                View Case Study →
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}