import { ArrowLeft, Calendar, User, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

export default function BlogDetail() {
  const [, setLocation] = useLocation();
  
  const blogContent = {
    title: "Facebook Ads vs Google Ads: Which is Better for Real Estate in 2024?",
    author: "DigiunixAds Team",
    date: "Dec 15, 2024",
    readTime: "8 min read",
    category: "Real Estate Marketing",
    image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=600"
  };

  const handleBackClick = () => {
    setLocation('/');
    // Scroll to blog section
    setTimeout(() => {
      const blogSection = document.getElementById('blog');
      if (blogSection) {
        blogSection.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Button 
            variant="ghost" 
            className="mb-6 text-gray-600 hover:text-black"
            onClick={handleBackClick}
          >
            <ArrowLeft className="mr-2 w-4 h-4" />
            Back to Blog
          </Button>
          
          <div className="mb-6">
            <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
              {blogContent.category}
            </span>
          </div>
          
          <h1 className="text-4xl lg:text-5xl font-bold text-black mb-6 leading-tight">
            {blogContent.title}
          </h1>
          
          <div className="flex items-center text-gray-600 mb-8">
            <User className="w-5 h-5 mr-2" />
            <span className="mr-6">{blogContent.author}</span>
            <Calendar className="w-5 h-5 mr-2" />
            <span className="mr-6">{blogContent.date}</span>
            <Clock className="w-5 h-5 mr-2" />
            <span>{blogContent.readTime}</span>
          </div>
        </div>
      </div>

      {/* Featured Image */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 -mt-16 mb-12">
        <div className="relative">
          <img 
            src={blogContent.image}
            alt={blogContent.title}
            className="w-full h-[400px] lg:h-[500px] object-cover rounded-2xl shadow-2xl"
          />
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="prose prose-lg max-w-none">
          <div className="text-gray-700 leading-relaxed space-y-6">
            
            <p className="text-xl font-medium text-gray-800 mb-8">
              Real estate marketing has evolved dramatically in recent years. With the rise of digital advertising, property developers and real estate agents now have powerful tools at their disposal. But which platform delivers better results for real estate businesses in 2024?
            </p>

            <h2 className="text-3xl font-bold text-black mt-12 mb-6">Understanding the Platforms</h2>

            <h3 className="text-2xl font-bold text-black mt-8 mb-4">Facebook Ads (Meta Ads)</h3>
            <p className="mb-6">
              Facebook Ads, now part of Meta's advertising ecosystem, includes Instagram and Facebook advertising. These platforms excel at:
            </p>
            <ul className="list-disc pl-6 space-y-2 mb-6">
              <li><strong>Visual storytelling</strong> through images and videos</li>
              <li><strong>Detailed targeting</strong> based on demographics, interests, and behaviors</li>
              <li><strong>Brand awareness</strong> and engagement building</li>
              <li><strong>Retargeting</strong> website visitors and custom audiences</li>
            </ul>

            <h3 className="text-2xl font-bold text-black mt-8 mb-4">Google Ads</h3>
            <p className="mb-6">
              Google Ads captures users at the moment of intent through:
            </p>
            <ul className="list-disc pl-6 space-y-2 mb-6">
              <li><strong>Search ads</strong> targeting specific keywords</li>
              <li><strong>Display network</strong> for visual campaigns</li>
              <li><strong>YouTube advertising</strong> for video content</li>
              <li><strong>Local campaigns</strong> for location-based businesses</li>
            </ul>

            <h2 className="text-3xl font-bold text-black mt-12 mb-6">Real Estate Lead Generation: The Numbers</h2>

            <p className="mb-6">Based on our experience with 50+ real estate clients in 2024:</p>

            <div className="bg-blue-50 p-6 rounded-xl mb-8">
              <h4 className="text-xl font-bold text-blue-800 mb-4">Facebook Ads Performance:</h4>
              <ul className="space-y-2 text-blue-700">
                <li><strong>Average Cost Per Lead</strong>: ₹250-₹800</li>
                <li><strong>Lead Quality Score</strong>: 7.2/10</li>
                <li><strong>Conversion Rate</strong>: 12-18%</li>
                <li><strong>Best for</strong>: Luxury properties, brand building, visual campaigns</li>
              </ul>
            </div>

            <div className="bg-green-50 p-6 rounded-xl mb-8">
              <h4 className="text-xl font-bold text-green-800 mb-4">Google Ads Performance:</h4>
              <ul className="space-y-2 text-green-700">
                <li><strong>Average Cost Per Lead</strong>: ₹400-₹1,200</li>
                <li><strong>Lead Quality Score</strong>: 8.5/10</li>
                <li><strong>Conversion Rate</strong>: 18-25%</li>
                <li><strong>Best for</strong>: High-intent searches, immediate buyers, local targeting</li>
              </ul>
            </div>

            <h2 className="text-3xl font-bold text-black mt-12 mb-6">Case Study: Sai Palace Residency, Pune</h2>

            <div className="bg-yellow-50 border-l-4 border-yellow-400 p-6 mb-8">
              <p><strong>Challenge</strong>: 150+ luxury flats unsold for 8 months</p>
              <p><strong>Strategy</strong>: Combined Facebook + Google Ads approach</p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 mb-8">
              <div className="bg-blue-50 p-6 rounded-xl">
                <h4 className="text-lg font-bold text-blue-800 mb-4">Facebook Ads Results (6 months):</h4>
                <ul className="space-y-2 text-blue-700">
                  <li>120 leads generated</li>
                  <li>₹350 average cost per lead</li>
                  <li>85 site visits booked</li>
                  <li>45 flat bookings</li>
                </ul>
              </div>
              
              <div className="bg-green-50 p-6 rounded-xl">
                <h4 className="text-lg font-bold text-green-800 mb-4">Google Ads Results (6 months):</h4>
                <ul className="space-y-2 text-green-700">
                  <li>95 leads generated</li>
                  <li>₹480 average cost per lead</li>
                  <li>78 site visits booked</li>
                  <li>55 flat bookings</li>
                </ul>
              </div>
            </div>

            <div className="bg-black text-white p-6 rounded-xl mb-8 text-center">
              <h4 className="text-xl font-bold text-yellow-400 mb-2">Total Outcome</h4>
              <p className="text-lg">180 flat bookings worth ₹2.5 Cr revenue</p>
            </div>

            <h2 className="text-3xl font-bold text-black mt-12 mb-6">Platform Comparison for Different Property Types</h2>

            <div className="space-y-6 mb-8">
              <div className="border-l-4 border-blue-400 pl-6">
                <h4 className="text-xl font-bold text-black mb-2">Luxury Residential Projects</h4>
                <p><strong>Winner</strong>: Facebook Ads</p>
                <ul className="list-disc pl-6 mt-2 space-y-1">
                  <li>Better visual showcase capabilities</li>
                  <li>Affluent audience targeting</li>
                  <li>Lifestyle-based marketing approach</li>
                </ul>
              </div>

              <div className="border-l-4 border-green-400 pl-6">
                <h4 className="text-xl font-bold text-black mb-2">Commercial Properties</h4>
                <p><strong>Winner</strong>: Google Ads</p>
                <ul className="list-disc pl-6 mt-2 space-y-1">
                  <li>Business-focused search intent</li>
                  <li>Professional targeting options</li>
                  <li>B2B lead generation</li>
                </ul>
              </div>

              <div className="border-l-4 border-yellow-400 pl-6">
                <h4 className="text-xl font-bold text-black mb-2">Budget Housing</h4>
                <p><strong>Winner</strong>: Tie</p>
                <ul className="list-disc pl-6 mt-2 space-y-1">
                  <li>Facebook for awareness campaigns</li>
                  <li>Google for high-intent searches</li>
                  <li>Combined approach recommended</li>
                </ul>
              </div>
            </div>

            <h2 className="text-3xl font-bold text-black mt-12 mb-6">Budget Allocation Recommendations</h2>

            <p className="mb-6">For most real estate businesses, we recommend:</p>

            <div className="grid md:grid-cols-2 gap-8 mb-8">
              <div className="bg-gray-50 p-6 rounded-xl">
                <h4 className="text-lg font-bold mb-4">70% Google Ads / 30% Facebook Ads</h4>
                <p className="font-semibold mb-2">Best for:</p>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Immediate sales targets</li>
                  <li>High-intent buyer capture</li>
                  <li>Local market dominance</li>
                </ul>
              </div>

              <div className="bg-gray-50 p-6 rounded-xl">
                <h4 className="text-lg font-bold mb-4">60% Facebook Ads / 40% Google Ads</h4>
                <p className="font-semibold mb-2">Best for:</p>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Brand building phase</li>
                  <li>Luxury property marketing</li>
                  <li>Long-term relationship building</li>
                </ul>
              </div>
            </div>

            <h2 className="text-3xl font-bold text-black mt-12 mb-6">The Verdict: Which Platform Wins?</h2>

            <div className="bg-gradient-to-r from-blue-50 to-green-50 p-8 rounded-xl mb-8">
              <div className="space-y-4">
                <p><strong>For immediate results and high-intent leads</strong>: Google Ads takes the lead</p>
                <p><strong>For brand building and visual storytelling</strong>: Facebook Ads excels</p>
                <p><strong>For maximum impact</strong>: A strategic combination of both platforms delivers the best results.</p>
              </div>
            </div>

            <h2 className="text-3xl font-bold text-black mt-12 mb-6">Our Recommendation</h2>

            <p className="mb-6">Based on 3+ years of real estate advertising experience:</p>

            <ol className="list-decimal pl-6 space-y-2 mb-8">
              <li><strong>Start with Google Ads</strong> for immediate lead generation</li>
              <li><strong>Add Facebook Ads</strong> for brand awareness and retargeting</li>
              <li><strong>Optimize continuously</strong> based on performance data</li>
              <li><strong>Test creative variations</strong> across both platforms</li>
              <li><strong>Integrate with offline marketing</strong> for maximum impact</li>
            </ol>

          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-16 bg-black rounded-2xl p-8 text-center">
          <h3 className="text-2xl font-bold text-white mb-4">
            Ready to Scale Your Real Estate Business?
          </h3>
          <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
            Get a free consultation and custom strategy for your property business. We'll analyze your market and create a proven plan for more leads and sales.
          </p>
          <Button className="bg-yellow-400 text-black hover:bg-yellow-500 px-8 py-3 font-semibold">
            Get Free Strategy Session
          </Button>
        </div>

        {/* Related Articles */}
        <div className="mt-16">
          <h3 className="text-2xl font-bold text-black mb-8">Related Articles</h3>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-gray-50 rounded-xl p-6 hover:shadow-lg transition-shadow">
              <h4 className="font-bold text-lg mb-3">Google Ads for Healthcare Centers: Complete Guide 2024</h4>
              <p className="text-gray-600 text-sm mb-4">Learn how medical practices can generate 300+ patient appointments monthly using targeted Google Ads campaigns.</p>
              <Button variant="ghost" className="text-black hover:text-yellow-600 p-0">
                Read More →
              </Button>
            </div>
            <div className="bg-gray-50 rounded-xl p-6 hover:shadow-lg transition-shadow">
              <h4 className="font-bold text-lg mb-3">YouTube Ads for Business Coaches: 1000+ Course Sales Strategy</h4>
              <p className="text-gray-600 text-sm mb-4">Discover the exact YouTube advertising framework that helped coaches achieve 10x revenue growth in 90 days.</p>
              <Button variant="ghost" className="text-black hover:text-yellow-600 p-0">
                Read More →
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}