import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import TargetNichesSection from "@/components/target-niches-section";
import AboutSection from "@/components/about-section";
import ServicesSection from "@/components/services-section";
import ResultsSection from "@/components/results-section";
import CaseStudiesSection from "@/components/case-studies-section";
import PackagesSection from "@/components/packages-section";
import PerformanceBasedSection from "@/components/performance-based-section";
import BlogSection from "@/components/blog-section";
import ContactSection from "@/components/contact-section";
import TrustElementsSection from "@/components/trust-elements-section";
import Footer from "@/components/footer";
import FloatingWhatsapp from "@/components/floating-whatsapp";

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <HeroSection />
      <TargetNichesSection />
      <ServicesSection />
      <ResultsSection />
      <CaseStudiesSection />
      <PackagesSection />
      <PerformanceBasedSection />
      <BlogSection />
      <AboutSection />
      <ContactSection />
      <TrustElementsSection />
      <Footer />
      <FloatingWhatsapp />
    </div>
  );
}
